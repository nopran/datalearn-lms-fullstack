# 📥 Cara Download dan Install DataLearn LMS

## 🎯 Langkah-Langkah

### 1. Download Project

Klik link download yang diberikan Claude, atau klik tombol "Download" di interface.

File akan terdownload sebagai **folder** atau **ZIP file** dengan nama `datalearn-lms-fullstack`.

### 2. Extract (Jika ZIP)

Jika download dalam bentuk ZIP:
- **Windows:** Klik kanan → Extract All → Pilih lokasi
- **Mac:** Double click file ZIP
- **Linux:** `unzip datalearn-lms-fullstack.zip`

### 3. Buka Folder

Setelah extract, struktur folder harus seperti ini:

```
datalearn-lms-fullstack/
├── backend/          ← Kode backend (API server)
├── frontend/         ← File HTML untuk website
├── database/         ← Database schema
├── docs/             ← Dokumentasi lengkap
├── README.md         ← Baca ini dulu!
└── SETUP.md          ← Panduan setup detail
```

### 4. Baca Dokumentasi

**Mulai dari sini:**
1. Baca `README.md` - Overview dan quick start
2. Baca `SETUP.md` - Panduan setup step-by-step yang detail
3. Ikuti instruksi di dalamnya

### 5. Install Requirements

Sebelum mulai, install dulu:

1. **Node.js 16+**
   - Download: https://nodejs.org
   - Pilih versi LTS
   - Install seperti biasa

2. **PostgreSQL 14+**
   - Download: https://www.postgresql.org/download/
   - Pilih sesuai OS Anda
   - Saat install, set password untuk user `postgres` (INGAT PASSWORD INI!)

### 6. Setup Database

Buka terminal/command prompt:

```bash
# Login PostgreSQL
psql -U postgres

# Buat database
CREATE DATABASE datalearn_lms;

# Keluar
\q

# Import schema (ganti path sesuai lokasi folder Anda)
cd path/ke/datalearn-lms-fullstack
psql -U postgres -d datalearn_lms -f database/schema.sql
```

**Atau pakai pgAdmin (GUI):**
1. Buka pgAdmin
2. Create Database → Nama: `datalearn_lms`
3. Query Tool → Open `database/schema.sql` → Execute

### 7. Setup Backend

```bash
cd backend
npm install

# Copy .env.example jadi .env
cp .env.example .env

# Edit .env, isi password database Anda
# Minimal yang HARUS diisi:
# DB_PASSWORD=password_postgres_anda
# JWT_SECRET=random-string-minimal-32-karakter

# Jalankan server
npm run dev
```

Jika berhasil, muncul:
```
✓ Database connection established successfully
Server running on port 5000
```

### 8. Buka Frontend

**Option A - Langsung:**
- Buka file `frontend/index.html` di browser

**Option B - Pakai server:**
```bash
cd frontend
npx http-server -p 3000
```

Buka browser: http://localhost:3000

### 9. Login Pertama

Login dengan akun admin default:
- Email: `admin@datalearn.com`
- Password: `admin123`

---

## ❓ Troubleshooting Download

### File tidak bisa didownload / Error

**Solusi:**
1. Refresh halaman Claude
2. Klik tombol download lagi
3. Atau, copy semua file manual:
   - Buat folder baru di komputer
   - Copy isi dari setiap folder (backend, frontend, database, docs)
   - Paste ke folder baru

### File corrupt / tidak bisa extract

**Solusi:**
1. Download ulang
2. Pakai software extract berbeda (7-Zip, WinRAR, The Unarchiver)
3. Check ukuran file - harus > 50KB

### Folder kosong setelah extract

**Solusi:**
1. Pastikan Anda extract ke folder yang benar
2. Check apakah ada subfolder di dalam
3. Atau download ulang

---

## 🔧 Struktur File yang Benar

Setelah download dan extract, Anda harus punya:

```
datalearn-lms-fullstack/
│
├── backend/
│   ├── config/
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── utils/
│   ├── server.js
│   ├── package.json
│   └── .env.example
│
├── frontend/
│   └── index.html (ukuran ~80KB)
│
├── database/
│   └── schema.sql (ukuran ~20KB)
│
├── docs/
│   ├── README.md
│   └── DEPLOYMENT.md
│
├── README.md
├── SETUP.md
└── package.json
```

**Check penting:**
- File `frontend/index.html` harus ada dan berukuran ~80KB
- File `database/schema.sql` harus ada dan berukuran ~20KB
- File `backend/package.json` harus ada
- Folder `backend/routes/` harus ada dan isi 8 file .js

Jika ada yang kurang, download ulang atau hubungi support.

---

## ✅ Next Steps

Setelah download dan extract berhasil:

1. ✅ Baca `README.md`
2. ✅ Ikuti `SETUP.md` untuk install
3. ✅ Jalankan aplikasi
4. ✅ Test fitur-fitur
5. ✅ Customize sesuai kebutuhan

---

## 📞 Butuh Bantuan?

Jika masih stuck:
1. Check ulang setiap langkah di atas
2. Baca `SETUP.md` untuk panduan lebih detail
3. Pastikan Node.js dan PostgreSQL sudah terinstall
4. Check apakah ada error message, google error tersebut

---

**Selamat mencoba! 🚀**
