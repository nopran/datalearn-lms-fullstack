# 🎓 DataLearn LMS - Full Stack Learning Management System

Platform Learning Management System (LMS) lengkap berbasis database dengan Node.js, Express, PostgreSQL, dan frontend modern.

---

## 📦 Isi Project

```
datalearn-lms-fullstack/
├── backend/              # API Server (Node.js + Express)
├── frontend/             # Web Interface (HTML + Tailwind CSS)
├── database/             # Database Schema (PostgreSQL)
├── docs/                 # Dokumentasi lengkap
├── README.md             # File ini
├── SETUP.md              # Panduan setup detail
└── install.sh            # Script instalasi otomatis
```

---

## ⚡ Quick Start (3 Langkah)

### Langkah 1: Download & Extract
Download file ini dan extract ke folder project Anda.

### Langkah 2: Install Requirements
Pastikan sudah install:
- **Node.js 16+** → [Download di sini](https://nodejs.org)
- **PostgreSQL 14+** → [Download di sini](https://www.postgresql.org/download/)

### Langkah 3: Setup Database

**Windows (Command Prompt):**
```cmd
psql -U postgres
CREATE DATABASE datalearn_lms;
\q
psql -U postgres -d datalearn_lms -f database/schema.sql
```

**Mac/Linux (Terminal):**
```bash
psql -U postgres
CREATE DATABASE datalearn_lms;
\q
psql -U postgres -d datalearn_lms -f database/schema.sql
```

Atau gunakan pgAdmin:
1. Buka pgAdmin
2. Create Database → Nama: `datalearn_lms`
3. Query Tool → Open File → Pilih `database/schema.sql`
4. Execute (F5)

---

## 🚀 Menjalankan Aplikasi

### Backend (Terminal 1):

```bash
cd backend
npm install
```

**Buat file `.env`** (copy dari `.env.example`):
```env
NODE_ENV=development
PORT=5000

DB_HOST=localhost
DB_PORT=5432
DB_NAME=datalearn_lms
DB_USER=postgres
DB_PASSWORD=password_postgres_anda

JWT_SECRET=rahasia-minimal-32-karakter-ganti-ini
```

**Jalankan server:**
```bash
npm run dev
```

✅ Backend jalan di: `http://localhost:5000`

### Frontend (Terminal 2):

**Option 1 - Langsung buka di browser:**
- Buka file `frontend/index.html` di browser

**Option 2 - Pakai http-server:**
```bash
cd frontend
npx http-server -p 3000
```

✅ Frontend jalan di: `http://localhost:3000`

---

## 🔑 Login Pertama Kali

Setelah database di-setup, gunakan akun default:

**Admin:**
- Email: `admin@datalearn.com`
- Password: `admin123`

**Instructor:**
- Email: `ahmad.wijaya@datalearn.com`
- Password: `instructor123`

⚠️ **Penting:** Ganti password ini setelah login pertama!

---

## ✨ Fitur Utama

### Untuk Siswa:
✅ Register & Login
✅ Browse & Enroll Courses
✅ Video Learning & Quiz
✅ Progress Tracking
✅ Digital Certificates
✅ Private 1-on-1 Sessions
✅ Multiple Payment Methods

### Untuk Admin/Instructor:
✅ Manage Courses & Users
✅ Create Modules & Quiz
✅ View Analytics & Reports
✅ Manage Payments
✅ Issue Certificates

---

## 🛠️ Troubleshooting

### Problem: "Cannot connect to database"
**Solusi:**
1. Pastikan PostgreSQL sudah jalan
   - Windows: Check Services → PostgreSQL
   - Mac: `brew services list`
   - Linux: `sudo systemctl status postgresql`
2. Check username & password di file `.env`
3. Test koneksi: `psql -U postgres -d datalearn_lms`

### Problem: "Port 5000 already in use"
**Solusi:**
Ganti port di `.env`:
```env
PORT=5001
```

### Problem: Frontend tidak bisa connect ke backend
**Solusi:**
Edit file `frontend/index.html`, cari baris ini (sekitar line 140):
```javascript
const API_URL = 'http://localhost:5000';
```
Ganti sesuai port backend Anda.

### Problem: "JWT_SECRET not found"
**Solusi:**
Pastikan file `.env` ada dan berisi `JWT_SECRET` minimal 32 karakter:
```env
JWT_SECRET=ini-adalah-secret-key-yang-sangat-rahasia-min-32-karakter
```

---

## 📚 Dokumentasi Lengkap

- **Setup Detail:** Baca `SETUP.md`
- **API Documentation:** Baca `docs/README.md`
- **Deployment Guide:** Baca `docs/DEPLOYMENT.md`
- **Database Schema:** Lihat `database/schema.sql`

---

## 🎯 Langkah Selanjutnya

1. ✅ Setup & jalankan aplikasi (ikuti panduan di atas)
2. ✅ Login dengan akun admin
3. ✅ Explore fitur-fitur yang ada
4. ✅ Customize sesuai kebutuhan
5. ✅ Deploy ke production (baca `docs/DEPLOYMENT.md`)

---

## 📞 Butuh Bantuan?

Jika ada error atau pertanyaan:
1. Cek bagian **Troubleshooting** di atas
2. Baca dokumentasi di folder `docs/`
3. Check error message di terminal

---

## 📋 Tech Stack

- **Backend:** Node.js, Express.js, PostgreSQL, Sequelize
- **Frontend:** HTML5, CSS3 (Tailwind), JavaScript
- **Auth:** JWT + bcrypt
- **Payment:** Midtrans (ready to integrate)
- **Email:** Nodemailer

---

**Dibuat dengan ❤️ untuk pembelajaran**

Selamat belajar membangun LMS! 🚀
