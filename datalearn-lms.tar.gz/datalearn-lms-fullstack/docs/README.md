# DataLearn LMS - Full Stack Learning Management System

![DataLearn Logo](https://via.placeholder.com/800x200/2563eb/ffffff?text=DataLearn+LMS)

## 🎓 Tentang Project

**DataLearn** adalah platform Learning Management System (LMS) lengkap yang dibangun dengan teknologi modern untuk memfasilitasi pembelajaran online dalam bidang Data Analytics. Platform ini mendukung video courses, quiz interaktif, sertifikat digital, dan private sessions dengan mentor.

### ✨ Fitur Utama

#### Untuk Siswa
- ✅ Registrasi & Login (Email/OAuth)
- ✅ Dashboard pribadi dengan tracking progress
- ✅ Marketplace kursus dengan filter & search
- ✅ Multiple payment methods (QRIS, E-wallet, Transfer Bank, PayPal)
- ✅ Video player & konten pembelajaran interaktif
- ✅ Quiz & assignments dengan auto-grading
- ✅ Progress tracking otomatis
- ✅ Sertifikat digital terverifikasi
- ✅ Booking private session dengan Zoom integration
- ✅ Riwayat pembayaran & invoice PDF

#### Untuk Instruktur/Admin
- ✅ Dashboard analytics (users, revenue, courses)
- ✅ Manajemen kursus (CRUD operations)
- ✅ Kelola modules & quiz
- ✅ Kelola jadwal private sessions
- ✅ Verifikasi pembayaran manual
- ✅ Generate & manage certificates
- ✅ View reports & statistics

---

## 🛠️ Tech Stack

### Backend
- **Runtime:** Node.js 16+
- **Framework:** Express.js
- **Database:** PostgreSQL 14+
- **ORM:** Sequelize
- **Authentication:** JWT (JSON Web Tokens)
- **File Upload:** Cloudinary
- **Payment Gateway:** Midtrans / Xendit
- **Email Service:** Nodemailer
- **PDF Generation:** PDFKit
- **Video Conferencing:** Zoom API

### Frontend
- **Framework:** React.js / Vanilla JavaScript
- **Styling:** Tailwind CSS
- **Icons:** Font Awesome
- **HTTP Client:** Axios
- **State Management:** Context API / Redux (optional)

### Database Schema
- PostgreSQL dengan 15+ tables
- Relational design dengan foreign keys
- Indexes untuk performance
- Triggers untuk automation
- Views untuk reporting

---

## 📁 Project Structure

```
lms-fullstack/
├── backend/
│   ├── config/
│   │   └── database.js           # Database configuration
│   ├── models/
│   │   ├── User.js               # User model
│   │   ├── Course.js             # Course model
│   │   ├── Order.js              # Order model
│   │   ├── Certificate.js        # Certificate model
│   │   └── ... (more models)
│   ├── routes/
│   │   ├── auth.routes.js        # Authentication routes
│   │   ├── course.routes.js      # Course routes
│   │   ├── payment.routes.js     # Payment routes
│   │   ├── certificate.routes.js # Certificate routes
│   │   └── ... (more routes)
│   ├── middleware/
│   │   └── auth.js               # Authentication middleware
│   ├── utils/
│   │   ├── email.js              # Email utilities
│   │   ├── pdf.js                # PDF generation
│   │   └── helpers.js            # Helper functions
│   ├── .env.example              # Environment variables template
│   ├── package.json              # Dependencies
│   └── server.js                 # Main server file
├── frontend/
│   └── lms-platform.html         # Single-page frontend app
├── database/
│   └── schema.sql                # Database schema & migrations
└── docs/
    ├── README.md                 # This file
    ├── API.md                    # API documentation
    └── DEPLOYMENT.md             # Deployment guide
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ dan npm 8+
- PostgreSQL 14+
- Git

### 1. Clone Repository

```bash
git clone https://github.com/yourusername/datalearn-lms.git
cd datalearn-lms
```

### 2. Database Setup

```bash
# Login ke PostgreSQL
psql -U postgres

# Buat database
CREATE DATABASE datalearn_lms;

# Keluar dari psql
\q

# Import schema
psql -U postgres -d datalearn_lms -f database/schema.sql
```

### 3. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Edit .env dengan credentials Anda
nano .env
```

**Konfigurasi .env yang penting:**
```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=datalearn_lms
DB_USER=postgres
DB_PASSWORD=your_password

# JWT
JWT_SECRET=your_very_secret_key_min_32_characters

# Email (Gmail example)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# Midtrans (Payment Gateway)
MIDTRANS_SERVER_KEY=your_midtrans_server_key
MIDTRANS_CLIENT_KEY=your_midtrans_client_key
```

```bash
# Start development server
npm run dev

# Server akan running di http://localhost:5000
```

### 4. Frontend Setup

Buka file `frontend/lms-platform.html` di browser atau serve menggunakan:

```bash
cd frontend

# Menggunakan Python
python3 -m http.server 3000

# Atau menggunakan Node.js http-server
npx http-server -p 3000

# Frontend akan running di http://localhost:3000
```

---

## 📝 Environment Variables

File `.env.example` berisi semua variabel yang diperlukan. Berikut penjelasannya:

### Server Configuration
- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port (default: 5000)
- `FRONTEND_URL` - Frontend URL untuk CORS

### Database
- `DB_HOST` - PostgreSQL host
- `DB_PORT` - PostgreSQL port (default: 5432)
- `DB_NAME` - Database name
- `DB_USER` - Database username
- `DB_PASSWORD` - Database password

### Authentication
- `JWT_SECRET` - Secret key untuk JWT (minimal 32 karakter)
- `JWT_EXPIRES_IN` - Token expiration (default: 7d)
- `BCRYPT_ROUNDS` - Bcrypt salt rounds (default: 10)

### Email Service
- `SMTP_HOST` - SMTP server host
- `SMTP_PORT` - SMTP port
- `SMTP_USER` - Email account
- `SMTP_PASS` - Email password/app password
- `EMAIL_FROM` - Sender email address

### Payment Gateway
- `MIDTRANS_SERVER_KEY` - Midtrans server key
- `MIDTRANS_CLIENT_KEY` - Midtrans client key
- `MIDTRANS_IS_PRODUCTION` - Production mode (true/false)

### File Storage
- `CLOUDINARY_CLOUD_NAME` - Cloudinary cloud name
- `CLOUDINARY_API_KEY` - Cloudinary API key
- `CLOUDINARY_API_SECRET` - Cloudinary API secret

### Zoom API
- `ZOOM_API_KEY` - Zoom API key
- `ZOOM_API_SECRET` - Zoom API secret
- `ZOOM_ACCOUNT_ID` - Zoom account ID

---

## 🔑 API Endpoints

### Authentication
```
POST   /api/auth/register          - Register new user
POST   /api/auth/login             - Login user
POST   /api/auth/verify-email      - Verify email
POST   /api/auth/forgot-password   - Request password reset
POST   /api/auth/reset-password    - Reset password
GET    /api/auth/me                - Get current user
```

### Courses
```
GET    /api/courses                - Get all courses
GET    /api/courses/:id            - Get course by ID
GET    /api/courses/slug/:slug     - Get course by slug
POST   /api/courses                - Create course (Auth: Instructor)
PUT    /api/courses/:id            - Update course (Auth: Instructor)
DELETE /api/courses/:id            - Delete course (Auth: Admin)
```

### Enrollments
```
POST   /api/enrollments            - Enroll in course (Auth: Student)
GET    /api/enrollments            - Get user enrollments (Auth)
GET    /api/enrollments/:id        - Get enrollment details (Auth)
PUT    /api/enrollments/:id/progress - Update progress (Auth)
```

### Payments
```
POST   /api/payments/create-transaction    - Create payment (Auth)
POST   /api/payments/webhook               - Payment webhook (Midtrans)
POST   /api/payments/manual-verification   - Upload payment proof (Auth)
GET    /api/payments/orders                - Get user orders (Auth)
GET    /api/payments/orders/:orderNumber   - Get order details (Auth)
```

### Certificates
```
GET    /api/certificates           - Get user certificates (Auth)
GET    /api/certificates/:id       - Get certificate by ID (Auth)
POST   /api/certificates/verify    - Verify certificate (Public)
GET    /api/certificates/:id/download - Download certificate PDF (Auth)
```

### Private Sessions
```
POST   /api/sessions/book          - Book private session (Auth)
GET    /api/sessions               - Get user sessions (Auth)
PUT    /api/sessions/:id           - Update session (Auth)
DELETE /api/sessions/:id           - Cancel session (Auth)
```

### Admin
```
GET    /api/admin/dashboard        - Get admin dashboard data (Auth: Admin)
GET    /api/admin/users            - Get all users (Auth: Admin)
PUT    /api/admin/users/:id        - Update user (Auth: Admin)
GET    /api/admin/reports          - Get reports (Auth: Admin)
```

**Dokumentasi API lengkap:** [API.md](./API.md)

---

## 💾 Database Schema

### Main Tables

1. **users** - User accounts (students, instructors, admin)
2. **courses** - Course information
3. **course_modules** - Course content modules
4. **quiz_questions** - Quiz questions
5. **user_courses** - Course enrollments
6. **module_progress** - Learning progress
7. **orders** - Purchase orders
8. **payments** - Payment transactions
9. **certificates** - Digital certificates
10. **private_sessions** - 1-on-1 sessions
11. **course_reviews** - Course ratings & reviews
12. **subscription_plans** - Subscription packages

### Key Relationships

- User → UserCourse (One-to-Many)
- Course → CourseModule (One-to-Many)
- Course → UserCourse (One-to-Many)
- User → Order (One-to-Many)
- Order → Payment (One-to-One)
- User → Certificate (One-to-Many)

**ERD Diagram:** Lihat [database/schema.sql](../database/schema.sql)

---

## 🔐 Security Features

### Authentication & Authorization
- JWT-based authentication
- Password hashing dengan bcrypt (10 rounds)
- Email verification
- Password reset dengan expiring tokens
- Role-based access control (RBAC)

### API Security
- Helmet.js untuk security headers
- CORS configuration
- Rate limiting (100 req/15min)
- Input validation dengan express-validator
- SQL injection protection (Sequelize ORM)
- XSS protection

### Payment Security
- Webhook signature verification
- SSL/TLS encryption
- PCI DSS compliant payment gateways
- Transaction logging

### Data Privacy
- GDPR compliant
- Password tidak pernah di-return dalam response
- Soft delete untuk data sensitivity

---

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage

# Run specific test file
npm test -- auth.test.js
```

### Test Coverage
- Unit tests untuk models & utilities
- Integration tests untuk API endpoints
- End-to-end tests untuk critical flows

---

## 📊 Performance Optimization

### Database
- Indexes pada foreign keys & search fields
- Query optimization dengan proper JOIN
- Connection pooling
- Database views untuk complex queries

### API
- Response compression (gzip)
- Pagination pada list endpoints
- Caching dengan Redis (optional)
- CDN untuk static assets

### Frontend
- Lazy loading untuk images & videos
- Code splitting
- Minification & bundling
- Service worker untuk offline access

---

## 🚀 Deployment

### Development
```bash
npm run dev
```

### Production

#### Backend Deployment (Railway/Heroku/VPS)

**Railway.app (Recommended):**
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Add PostgreSQL database
railway add

# Deploy
railway up
```

**Manual VPS Deployment:**
```bash
# Di server (Ubuntu)
sudo apt update
sudo apt install nodejs npm postgresql

# Clone project
git clone https://github.com/yourusername/datalearn-lms.git
cd datalearn-lms/backend

# Install dependencies
npm install --production

# Setup environment
cp .env.example .env
nano .env

# Install PM2 untuk process management
npm install -g pm2

# Start aplikasi
pm2 start server.js --name datalearn-api

# Setup nginx sebagai reverse proxy
sudo apt install nginx
```

**Nginx Configuration:**
```nginx
server {
    listen 80;
    server_name api.datalearn.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### Frontend Deployment (Vercel/Netlify)

**Vercel:**
```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
cd frontend
vercel
```

**Netlify:**
Drag & drop folder `frontend` ke [netlify.com/drop](https://app.netlify.com/drop)

#### Database Deployment

**Neon.tech (Free PostgreSQL):**
1. Daftar di [neon.tech](https://neon.tech)
2. Buat database baru
3. Copy connection string
4. Update `DB_HOST`, `DB_USER`, `DB_PASSWORD` di .env

**Supabase (Alternative):**
1. Daftar di [supabase.com](https://supabase.com)
2. Buat project baru
3. Gunakan connection string dari dashboard

---

## 📱 API Testing

Gunakan Postman/Insomnia untuk testing API.

**Import Postman Collection:**
```bash
# Download collection
curl -O https://your-domain.com/postman-collection.json

# Import ke Postman
```

**Contoh Request:**

```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123",
    "fullName": "John Doe"
  }'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'

# Get courses (dengan auth)
curl -X GET http://localhost:5000/api/courses \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

---

## 🐛 Troubleshooting

### Database Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
**Solution:**
- Pastikan PostgreSQL running: `sudo service postgresql start`
- Check credentials di `.env`
- Test koneksi: `psql -U postgres -d datalearn_lms`

### JWT Token Error
```
Error: Invalid token
```
**Solution:**
- Pastikan `JWT_SECRET` di .env tidak kosong
- Token mungkin expired, login ulang
- Check format header: `Authorization: Bearer <token>`

### Email Sending Failed
```
Error: Failed to send email
```
**Solution:**
- Jika pakai Gmail, enable "Less secure app access"
- Atau gunakan App Password
- Check SMTP credentials di .env

### Payment Webhook Not Working
```
Error: Invalid signature
```
**Solution:**
- Verify Midtrans webhook URL di dashboard
- Check `MIDTRANS_SERVER_KEY` di .env
- Test dengan Midtrans simulator

---

## 📚 Documentation

- **API Documentation:** [API.md](./API.md)
- **Deployment Guide:** [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Database Schema:** [database/schema.sql](../database/schema.sql)
- **Frontend Guide:** [frontend/README.md](../frontend/README.md)

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👥 Team

- **Backend Developer:** Your Name
- **Frontend Developer:** Your Name
- **Database Designer:** Your Name
- **DevOps Engineer:** Your Name

---

## 📞 Support

Untuk pertanyaan atau issues:
- Email: support@datalearn.com
- GitHub Issues: [github.com/yourusername/datalearn-lms/issues](https://github.com/yourusername/datalearn-lms/issues)
- Discord: [discord.gg/datalearn](https://discord.gg/datalearn)

---

## 🎉 Acknowledgments

- Express.js team
- Sequelize ORM
- Midtrans Payment Gateway
- Tailwind CSS
- Font Awesome

---

**Made with ❤️ by DataLearn Team**
