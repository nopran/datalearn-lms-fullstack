# 🚀 Deployment Guide - DataLearn LMS

Panduan lengkap untuk deploy DataLearn LMS ke berbagai platform hosting.

---

## 📋 Table of Contents

1. [Persiapan Deploy](#persiapan-deploy)
2. [Backend Deployment](#backend-deployment)
   - [Railway.app](#railwayapp-recommended)
   - [Heroku](#heroku)
   - [VPS (DigitalOcean/AWS)](#vps-digitaloceanaws)
3. [Database Deployment](#database-deployment)
   - [Neon.tech](#neontech-free)
   - [Supabase](#supabase)
   - [Railway PostgreSQL](#railway-postgresql)
4. [Frontend Deployment](#frontend-deployment)
   - [Vercel](#vercel-recommended)
   - [Netlify](#netlify)
5. [Domain & SSL](#domain--ssl)
6. [Post-Deployment](#post-deployment)
7. [Monitoring & Maintenance](#monitoring--maintenance)

---

## ⚙️ Persiapan Deploy

### 1. Checklist Sebelum Deploy

- [ ] Semua environment variables sudah disiapkan
- [ ] Database schema sudah di-test locally
- [ ] Payment gateway credentials sudah valid
- [ ] Email service sudah dikonfigurasi
- [ ] API sudah di-test dengan Postman
- [ ] Frontend sudah terintegrasi dengan backend
- [ ] Backup database local

### 2. Environment Variables Production

Siapkan file `.env.production`:

```env
# Server
NODE_ENV=production
PORT=5000
API_URL=https://api.yourdomain.com
FRONTEND_URL=https://yourdomain.com

# Database (akan diisi setelah deploy database)
DB_HOST=your-db-host.com
DB_PORT=5432
DB_NAME=datalearn_lms
DB_USER=your-db-user
DB_PASSWORD=your-secure-password

# JWT (generate random 64 char)
JWT_SECRET=your-very-long-secret-key-min-64-characters-use-crypto-randomBytes
JWT_EXPIRES_IN=7d

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@yourdomain.com
SMTP_PASS=your-app-password

# Payment (Production keys)
MIDTRANS_SERVER_KEY=your-production-server-key
MIDTRANS_CLIENT_KEY=your-production-client-key
MIDTRANS_IS_PRODUCTION=true

# Cloudinary
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret

# Security
BCRYPT_ROUNDS=12
RATE_LIMIT_MAX_REQUESTS=100
```

---

## 🖥️ Backend Deployment

### Railway.app (Recommended)

**Kelebihan:**
- ✅ Free tier generous (500 hours/month)
- ✅ Integrated PostgreSQL
- ✅ Auto-deploy from GitHub
- ✅ Easy environment variables management

**Steps:**

#### 1. Install Railway CLI

```bash
npm install -g @railway/cli
```

#### 2. Login

```bash
railway login
```

#### 3. Initialize Project

```bash
cd backend
railway init
```

#### 4. Link to GitHub (Optional)

```bash
railway link
```

#### 5. Add PostgreSQL Database

```bash
railway add --plugin postgres
```

Railway akan otomatis membuat database dan set environment variables:
- `PGHOST`
- `PGPORT`
- `PGUSER`
- `PGPASSWORD`
- `PGDATABASE`
- `DATABASE_URL`

#### 6. Set Environment Variables

```bash
railway variables set NODE_ENV=production
railway variables set JWT_SECRET=your-secret-key
railway variables set SMTP_USER=your-email
railway variables set SMTP_PASS=your-password
# ... set semua variables lainnya
```

Atau via Railway Dashboard → Variables tab

#### 7. Deploy

```bash
railway up
```

#### 8. Run Database Migration

```bash
railway run psql -d $DATABASE_URL -f ../database/schema.sql
```

#### 9. Get Public URL

```bash
railway domain
```

Output: `https://your-app.up.railway.app`

---

### Heroku

**Steps:**

#### 1. Install Heroku CLI

```bash
# macOS
brew tap heroku/brew && brew install heroku

# Windows
# Download dari: https://devcenter.heroku.com/articles/heroku-cli

# Linux
curl https://cli-assets.heroku.com/install.sh | sh
```

#### 2. Login

```bash
heroku login
```

#### 3. Create App

```bash
cd backend
heroku create datalearn-api
```

#### 4. Add PostgreSQL

```bash
heroku addons:create heroku-postgresql:mini
```

#### 5. Set Environment Variables

```bash
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=your-secret-key
heroku config:set FRONTEND_URL=https://yourdomain.com
# ... set all variables
```

#### 6. Create Procfile

```bash
echo "web: node server.js" > Procfile
```

#### 7. Deploy

```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

#### 8. Run Migration

```bash
heroku run bash
psql $DATABASE_URL -f database/schema.sql
exit
```

#### 9. Open App

```bash
heroku open
```

---

### VPS (DigitalOcean/AWS)

**Untuk yang butuh kontrol penuh dan custom configuration.**

#### 1. Create Droplet/EC2 Instance

**DigitalOcean:**
- OS: Ubuntu 22.04 LTS
- Plan: Basic ($6/month)
- Region: Singapore/Singapore

**Specs minimum:**
- RAM: 1GB
- Storage: 25GB SSD
- Bandwidth: 1TB

#### 2. SSH ke Server

```bash
ssh root@your-server-ip
```

#### 3. Initial Server Setup

```bash
# Update system
apt update && apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Install PostgreSQL
apt install -y postgresql postgresql-contrib

# Install nginx
apt install -y nginx

# Install PM2
npm install -g pm2

# Install git
apt install -y git
```

#### 4. Setup PostgreSQL

```bash
# Switch to postgres user
sudo -u postgres psql

# Create database dan user
CREATE DATABASE datalearn_lms;
CREATE USER datalearn_user WITH ENCRYPTED PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE datalearn_lms TO datalearn_user;
\q
```

#### 5. Clone & Setup Application

```bash
# Create app directory
mkdir -p /var/www/datalearn
cd /var/www/datalearn

# Clone repository
git clone https://github.com/yourusername/datalearn-lms.git .

# Install dependencies
cd backend
npm install --production

# Create .env file
nano .env
# Paste your production environment variables

# Run database migration
psql -U datalearn_user -d datalearn_lms -f ../database/schema.sql
```

#### 6. Setup PM2

```bash
# Start application
pm2 start server.js --name datalearn-api

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Copy and run the command that PM2 outputs
```

#### 7. Configure Nginx

```bash
nano /etc/nginx/sites-available/datalearn
```

Paste configuration:

```nginx
server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # File upload limit
    client_max_body_size 10M;
}
```

Enable site:

```bash
ln -s /etc/nginx/sites-available/datalearn /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

#### 8. Setup SSL with Let's Encrypt

```bash
# Install Certbot
apt install -y certbot python3-certbot-nginx

# Get certificate
certbot --nginx -d api.yourdomain.com

# Auto-renewal (sudah otomatis, test dengan)
certbot renew --dry-run
```

#### 9. Setup Firewall

```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

---

## 💾 Database Deployment

### Neon.tech (Free)

**Kelebihan:**
- ✅ Free tier: 0.5GB storage
- ✅ Serverless PostgreSQL
- ✅ Auto-scaling
- ✅ Branching support

**Steps:**

1. Daftar di [neon.tech](https://neon.tech)
2. Create new project
3. Copy connection string
4. Update `.env`:

```env
DATABASE_URL=postgresql://user:password@host.neon.tech/dbname?sslmode=require
```

5. Run migration:

```bash
psql $DATABASE_URL -f database/schema.sql
```

---

### Supabase

**Kelebihan:**
- ✅ Free tier: 500MB storage
- ✅ Realtime capabilities
- ✅ Built-in authentication
- ✅ Auto-generated REST API

**Steps:**

1. Daftar di [supabase.com](https://supabase.com)
2. Create new project
3. Go to Settings → Database → Connection string
4. Update `.env`:

```env
DB_HOST=db.xxxxx.supabase.co
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=your-password
```

5. Run migration via Supabase SQL Editor atau psql

---

## 🌐 Frontend Deployment

### Vercel (Recommended)

**Kelebihan:**
- ✅ Free tier unlimited
- ✅ Auto-deploy from GitHub
- ✅ Global CDN
- ✅ Built-in SSL

**Steps:**

#### 1. Install Vercel CLI

```bash
npm install -g vercel
```

#### 2. Login

```bash
vercel login
```

#### 3. Deploy

```bash
cd frontend
vercel
```

Follow prompts:
- Set project name
- Set root directory to `./`
- No build command needed (static HTML)

#### 4. Update API URL

Update `lms-platform.html`:

```javascript
const API_URL = 'https://your-api-url.railway.app';
```

#### 5. Redeploy

```bash
vercel --prod
```

---

### Netlify

**Steps:**

#### 1. Via Netlify Drop (Easiest)

1. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag & drop your `frontend` folder
3. Done! Your site is live

#### 2. Via Netlify CLI

```bash
# Install CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
cd frontend
netlify deploy --prod
```

---

## 🌍 Domain & SSL

### Setup Custom Domain

#### Vercel

1. Go to Project Settings → Domains
2. Add your domain (e.g., datalearn.com)
3. Update DNS records at your domain provider:

```
Type: CNAME
Name: @
Value: cname.vercel-dns.com
```

#### Railway/Heroku

1. Go to Settings → Domains
2. Add custom domain
3. Update DNS:

```
Type: CNAME
Name: api
Value: your-app.up.railway.app
```

### SSL Certificate

- Vercel & Netlify: **Automatic** (Let's Encrypt)
- Railway & Heroku: **Automatic**
- VPS: Use **Certbot** (sudah dijelaskan di atas)

---

## ✅ Post-Deployment

### 1. Test API Endpoints

```bash
# Health check
curl https://api.yourdomain.com/health

# Test registration
curl -X POST https://api.yourdomain.com/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "fullName": "Test User"
  }'
```

### 2. Setup Monitoring

**Sentry (Error Tracking):**

```bash
npm install @sentry/node
```

Add to `server.js`:

```javascript
const Sentry = require('@sentry/node');

Sentry.init({
  dsn: 'your-sentry-dsn',
  environment: process.env.NODE_ENV
});
```

**UptimeRobot (Uptime Monitoring):**

1. Daftar di [uptimerobot.com](https://uptimerobot.com)
2. Add monitor untuk API URL
3. Set alert via email/SMS

### 3. Setup Analytics

**Google Analytics:**

Add to frontend `<head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### 4. Backup Strategy

**Automated Database Backups:**

```bash
# Cron job untuk daily backup
0 2 * * * pg_dump -U datalearn_user datalearn_lms | gzip > /backups/db_$(date +\%Y\%m\%d).sql.gz
```

**Railway:**
Railway otomatis backup database setiap hari

---

## 📊 Monitoring & Maintenance

### Log Management

**PM2 Logs:**

```bash
pm2 logs datalearn-api
pm2 logs --lines 100
```

**Railway Logs:**

```bash
railway logs
```

**Heroku Logs:**

```bash
heroku logs --tail
```

### Performance Monitoring

1. **New Relic** (APM)
2. **DataDog** (Infrastructure)
3. **LogRocket** (Frontend monitoring)

### Database Maintenance

```bash
# Vacuum database (cleanup)
psql -U postgres -d datalearn_lms -c "VACUUM ANALYZE;"

# Check database size
psql -U postgres -d datalearn_lms -c "SELECT pg_size_pretty(pg_database_size('datalearn_lms'));"
```

### SSL Certificate Renewal

**Automatic (Let's Encrypt):**

Certbot automatically renews certificates. Test with:

```bash
certbot renew --dry-run
```

---

## 🔧 Troubleshooting

### Database Connection Failed

```bash
# Check if PostgreSQL is running
systemctl status postgresql

# Check connection
psql -U datalearn_user -d datalearn_lms -h localhost

# Check firewall
ufw status
```

### API Returns 502 Bad Gateway

```bash
# Check if Node.js app is running
pm2 status

# Restart app
pm2 restart datalearn-api

# Check logs
pm2 logs datalearn-api --lines 50
```

### High Memory Usage

```bash
# Check memory
free -h

# Restart app to clear memory leaks
pm2 restart datalearn-api

# Or increase server RAM
```

---

## 📞 Support

Jika ada masalah deployment:

- **Email:** devops@datalearn.com
- **Discord:** [discord.gg/datalearn](https://discord.gg/datalearn)
- **Documentation:** [docs.datalearn.com](https://docs.datalearn.com)

---

**Happy Deploying! 🚀**
