const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');

router.get('/dashboard', authenticate, authorize('admin'), (req, res) => {
  res.json({ success: true, message: 'Admin dashboard endpoint' });
});

router.get('/users', authenticate, authorize('admin'), (req, res) => {
  res.json({ success: true, message: 'Get all users endpoint' });
});

module.exports = router;
