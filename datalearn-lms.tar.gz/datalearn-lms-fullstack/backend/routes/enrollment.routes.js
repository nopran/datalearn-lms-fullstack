const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');

// Placeholder routes - implement models first
router.get('/', authenticate, (req, res) => {
  res.json({ success: true, message: 'Get enrollments endpoint' });
});

router.post('/', authenticate, (req, res) => {
  res.json({ success: true, message: 'Create enrollment endpoint' });
});

module.exports = router;
