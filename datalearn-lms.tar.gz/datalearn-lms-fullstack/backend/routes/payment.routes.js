const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const axios = require('axios');
const { authenticate } = require('../middleware/auth');

// Note: Install Midtrans SDK: npm install midtrans-client
// const midtransClient = require('midtrans-client');

// @route   POST /api/payments/create-transaction
// @desc    Create payment transaction
// @access  Private
router.post('/create-transaction', authenticate, async (req, res) => {
  try {
    const { orderId, amount, itemDetails, customerDetails } = req.body;

    // Generate order number
    const orderNumber = `ORDER-${Date.now()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

    // Midtrans configuration
    const snap = new midtransClient.Snap({
      isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
      serverKey: process.env.MIDTRANS_SERVER_KEY,
      clientKey: process.env.MIDTRANS_CLIENT_KEY
    });

    // Create transaction parameter
    const parameter = {
      transaction_details: {
        order_id: orderNumber,
        gross_amount: amount
      },
      item_details: itemDetails,
      customer_details: customerDetails || {
        first_name: req.user.fullName,
        email: req.user.email,
        phone: req.user.phone
      },
      credit_card: {
        secure: true
      },
      enabled_payments: [
        'credit_card',
        'bca_va',
        'bni_va',
        'bri_va',
        'gopay',
        'shopeepay',
        'qris'
      ]
    };

    // Create transaction
    const transaction = await snap.createTransaction(parameter);

    // Save order to database
    const Order = require('../models/Order');
    await Order.create({
      userId: req.user.id,
      orderNumber,
      orderType: req.body.orderType,
      itemId: req.body.itemId,
      amount,
      finalAmount: amount,
      status: 'pending',
      paymentMethod: 'midtrans'
    });

    res.json({
      success: true,
      data: {
        token: transaction.token,
        redirectUrl: transaction.redirect_url,
        orderNumber
      }
    });

  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create transaction',
      error: error.message
    });
  }
});

// @route   POST /api/payments/webhook
// @desc    Handle payment webhook from Midtrans
// @access  Public (with verification)
router.post('/webhook', async (req, res) => {
  try {
    const {
      order_id,
      transaction_status,
      fraud_status,
      signature_key
    } = req.body;

    // Verify signature
    const serverKey = process.env.MIDTRANS_SERVER_KEY;
    const signatureInput = `${order_id}${transaction_status}${req.body.gross_amount}${serverKey}`;
    const expectedSignature = crypto
      .createHash('sha512')
      .update(signatureInput)
      .digest('hex');

    if (signature_key !== expectedSignature) {
      return res.status(403).json({
        success: false,
        message: 'Invalid signature'
      });
    }

    // Update order status
    const Order = require('../models/Order');
    const order = await Order.findOne({
      where: { orderNumber: order_id }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Handle different transaction status
    if (transaction_status === 'capture' || transaction_status === 'settlement') {
      if (fraud_status === 'accept') {
        order.status = 'paid';
        await order.save();

        // Process enrollment or subscription
        if (order.orderType === 'course') {
          const UserCourse = require('../models/UserCourse');
          await UserCourse.create({
            userId: order.userId,
            courseId: order.itemId,
            enrollmentType: 'purchase'
          });
        }

        // Send confirmation email
        const User = require('../models/User');
        const user = await User.findByPk(order.userId);
        
        // TODO: Send email notification
      }
    } else if (transaction_status === 'cancel' || transaction_status === 'deny' || transaction_status === 'expire') {
      order.status = 'failed';
      await order.save();
    } else if (transaction_status === 'pending') {
      order.status = 'pending';
      await order.save();
    }

    res.json({
      success: true,
      message: 'Webhook processed'
    });

  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({
      success: false,
      message: 'Webhook processing failed',
      error: error.message
    });
  }
});

// @route   POST /api/payments/manual-verification
// @desc    Manual payment verification (for bank transfer)
// @access  Private
router.post('/manual-verification', authenticate, async (req, res) => {
  try {
    const { orderNumber, proofOfPayment } = req.body;

    const Order = require('../models/Order');
    const order = await Order.findOne({
      where: {
        orderNumber,
        userId: req.user.id
      }
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    const Payment = require('../models/Payment');
    await Payment.create({
      orderId: order.id,
      paymentGateway: 'manual_transfer',
      amount: order.finalAmount,
      status: 'pending',
      paymentProof: proofOfPayment
    });

    // Notify admin for verification
    // TODO: Send notification to admin

    res.json({
      success: true,
      message: 'Payment proof submitted. We will verify within 24 hours.'
    });

  } catch (error) {
    console.error('Manual verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit payment proof',
      error: error.message
    });
  }
});

// @route   GET /api/payments/orders
// @desc    Get user's orders
// @access  Private
router.get('/orders', authenticate, async (req, res) => {
  try {
    const Order = require('../models/Order');
    const orders = await Order.findAll({
      where: { userId: req.user.id },
      order: [['createdAt', 'DESC']],
      include: ['payment']
    });

    res.json({
      success: true,
      data: { orders }
    });

  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch orders',
      error: error.message
    });
  }
});

// @route   GET /api/payments/orders/:orderNumber
// @desc    Get order details
// @access  Private
router.get('/orders/:orderNumber', authenticate, async (req, res) => {
  try {
    const Order = require('../models/Order');
    const order = await Order.findOne({
      where: {
        orderNumber: req.params.orderNumber,
        userId: req.user.id
      },
      include: ['payment']
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.json({
      success: true,
      data: { order }
    });

  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch order',
      error: error.message
    });
  }
});

module.exports = router;
