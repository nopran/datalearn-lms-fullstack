const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');

router.get('/profile', authenticate, (req, res) => {
  res.json({ success: true, data: { user: req.user.toJSON() } });
});

router.put('/profile', authenticate, async (req, res) => {
  try {
    const { fullName, phone } = req.body;
    await req.user.update({ fullName, phone });
    res.json({ success: true, message: 'Profile updated', data: { user: req.user.toJSON() } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
