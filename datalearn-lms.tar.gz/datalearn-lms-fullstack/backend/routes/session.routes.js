const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');

router.post('/book', authenticate, (req, res) => {
  res.json({ success: true, message: 'Book session endpoint' });
});

router.get('/', authenticate, (req, res) => {
  res.json({ success: true, message: 'Get sessions endpoint' });
});

module.exports = router;
