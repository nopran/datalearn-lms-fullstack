const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');

router.get('/', authenticate, (req, res) => {
  res.json({ success: true, message: 'Get certificates endpoint' });
});

router.get('/:id/download', authenticate, (req, res) => {
  res.json({ success: true, message: 'Download certificate endpoint' });
});

module.exports = router;
