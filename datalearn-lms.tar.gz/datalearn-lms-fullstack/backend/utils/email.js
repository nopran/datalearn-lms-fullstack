const nodemailer = require('nodemailer');

// Create transporter
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
};

// Send email function
const sendEmail = async ({ to, subject, text, html }) => {
  try {
    const transporter = createTransporter();

    const mailOptions = {
      from: process.env.EMAIL_FROM || process.env.SMTP_USER,
      to,
      subject,
      text,
      html
    };

    const info = await transporter.sendMail(mailOptions);
    
    console.log('Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };

  } catch (error) {
    console.error('Email sending failed:', error);
    throw new Error(`Failed to send email: ${error.message}`);
  }
};

// Email templates
const emailTemplates = {
  welcome: (name) => ({
    subject: 'Welcome to DataLearn!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">Welcome to DataLearn, ${name}!</h1>
        <p>Thank you for joining our learning platform.</p>
        <p>You can now access all our courses and start your learning journey.</p>
        <a href="${process.env.FRONTEND_URL}/dashboard" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px; margin-top: 16px;">
          Go to Dashboard
        </a>
      </div>
    `
  }),

  enrollmentConfirmation: (name, courseName) => ({
    subject: `You're enrolled in ${courseName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">Enrollment Confirmed!</h1>
        <p>Hi ${name},</p>
        <p>You have successfully enrolled in <strong>${courseName}</strong>.</p>
        <p>Start learning now and achieve your goals!</p>
        <a href="${process.env.FRONTEND_URL}/my-courses" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px; margin-top: 16px;">
          Start Learning
        </a>
      </div>
    `
  }),

  certificateIssued: (name, courseName, certificateUrl) => ({
    subject: `Your Certificate for ${courseName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">Congratulations! 🎉</h1>
        <p>Hi ${name},</p>
        <p>You have successfully completed <strong>${courseName}</strong>!</p>
        <p>Your certificate is now ready to download.</p>
        <a href="${certificateUrl}" style="display: inline-block; padding: 12px 24px; background-color: #16a34a; color: white; text-decoration: none; border-radius: 6px; margin-top: 16px;">
          Download Certificate
        </a>
      </div>
    `
  }),

  sessionReminder: (name, topic, date, time, zoomLink) => ({
    subject: `Reminder: Private Session Tomorrow`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">Session Reminder</h1>
        <p>Hi ${name},</p>
        <p>This is a reminder for your private session:</p>
        <ul>
          <li><strong>Topic:</strong> ${topic}</li>
          <li><strong>Date:</strong> ${date}</li>
          <li><strong>Time:</strong> ${time}</li>
        </ul>
        <a href="${zoomLink}" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px; margin-top: 16px;">
          Join Zoom Meeting
        </a>
      </div>
    `
  }),

  paymentSuccess: (name, orderNumber, amount, courseName) => ({
    subject: 'Payment Successful',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #16a34a;">Payment Successful! ✓</h1>
        <p>Hi ${name},</p>
        <p>Your payment has been successfully processed.</p>
        <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 16px 0;">
          <p><strong>Order Number:</strong> ${orderNumber}</p>
          <p><strong>Amount:</strong> Rp ${amount.toLocaleString('id-ID')}</p>
          <p><strong>Item:</strong> ${courseName}</p>
        </div>
        <a href="${process.env.FRONTEND_URL}/my-courses" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px; margin-top: 16px;">
          Access Your Course
        </a>
      </div>
    `
  })
};

module.exports = {
  sendEmail,
  emailTemplates
};
