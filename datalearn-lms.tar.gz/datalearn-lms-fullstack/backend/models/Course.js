const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Course = sequelize.define('Course', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  slug: {
    type: DataTypes.STRING(255),
    unique: true,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  instructorId: {
    type: DataTypes.INTEGER,
    field: 'instructor_id',
    references: {
      model: 'users',
      key: 'id'
    }
  },
  category: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  level: {
    type: DataTypes.ENUM('beginner', 'intermediate', 'advanced'),
    allowNull: true
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  thumbnail: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  durationWeeks: {
    type: DataTypes.INTEGER,
    field: 'duration_weeks'
  },
  language: {
    type: DataTypes.STRING(20),
    defaultValue: 'id'
  },
  requirements: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  whatYouLearn: {
    type: DataTypes.JSONB,
    field: 'what_you_learn'
  },
  isPublished: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_published'
  },
  totalStudents: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'total_students'
  },
  averageRating: {
    type: DataTypes.DECIMAL(3, 2),
    defaultValue: 0.00,
    field: 'average_rating'
  },
  totalReviews: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'total_reviews'
  }
}, {
  tableName: 'courses',
  timestamps: true
});

module.exports = Course;
